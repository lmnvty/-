#!/system/bin/sh
# ============================================================
#  温控放宽 v2.1 · 模块内置卸载脚本
#  由 KernelSU/Magisk 卸载时自动调用；
#  也可手动： su -c "sh /data/adb/modules/thermal_relax/uninstall.sh"
#
#  注意：只按 'thermal_relax_guard' 精确匹配，避免杀掉脚本自身
# ============================================================
SELF=$$
PARENT=$PPID

for p in $(ps -A -o PID,ARGS 2>/dev/null | grep 'thermal_relax_guard' | grep -v grep | awk '{print $1}'); do
  [ "$p" = "$SELF" ] && continue
  [ "$p" = "$PARENT" ] && continue
  kill -9 "$p" 2>/dev/null
done

MODDIR=${0%/*}
[ -f "$MODDIR/daemon.pid" ] && kill -9 "$(cat $MODDIR/daemon.pid 2>/dev/null)" 2>/dev/null
rm -f "$MODDIR/daemon.pid" 2>/dev/null

echo "thermal_relax: daemon stopped"