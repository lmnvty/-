# 温控放宽 (Thermal Relax) v2.1

KernelSU / Magisk 模块 · 只写 `/sys` 运行时节点，**零系统分区写入**，重启即恢复原厂。

## 放宽项

| 项目 | 节点 | 效果 |
|---|---|---|
| CPU 免温控上限 | `thermal_message/cpu_nolimit_temp` | 原厂 48000 → **50000** |
| WiFi 过热降速 | `thermal_message/wifi_limit` | 1 → **0**（解除） |
| 温控降亮度 | `thermal_message/thermal_max_brightness` | 1 → **0**（解除） |
| 背光满血 | `backlight/panel0-backlight/brightness` | 拉到 **max（4095）** |
| 商店下载限速 | `thermal_message/market_download_limit` | 1 → **0**（解除） |
| **充电不受温度限流** | `cooling_device*/battery/cur_state` | 拉到 **max_state** |

> 充电项只解除**温度对充电电流的压制**，不改电流/电压硬件上限。

## 检查式重写（v2.1 核心）

不再是"盲写"，而是**先读后写**：

```
亮屏 → 检查1次
     → 等 5 秒再检查1次
     → 之后每 90 秒检查1次
灭屏 → 每 120 秒只检查「充电 / CPU」（不碰亮度，省电）
```

**每次"检查"的逻辑：**

- 值 = 本模块设定的值 → **不写**（省电、少 IO）
- 值被改回原厂（如 mi_thermald 回写）→ **立即重写回来**

因此日志只在**真正发生重写**时才记录一行。

## 安装

1. 打包：把本目录内容压成 zip（`module.prop` 在 zip 根目录）
2. KernelSU 管理器 → 模块 → 从本地安装 → 选 zip
3. 重启

## 自检

```sh
su -c "sh /data/adb/modules/thermal_relax/test.sh"
```

## 卸载

```sh
su -c "sh /data/adb/modules/thermal_relax/uninstall.sh"
```
然后删除目录 `/data/adb/modules/thermal_relax` 并重启。

## 调参

改 `config.sh` 后重启生效：

```sh
NOLIMIT_TEMP=50000        # CPU 免温控上限（45000温和 / 48000原厂 / 50000推荐 / 52000激进）
RELAX_WIFI=1              # 解除 WiFi 降速
RELAX_BRIGHT=1            # 解除降亮度 + 背光满血
RELAX_MARKET=1            # 解除商店限速
RELAX_CHARGE=1            # 充电不受温度限流
ON_INTERVAL=90            # 亮屏检查间隔（秒）
FIRST_REWRITE_DELAY=5     # 亮屏后第二次检查延迟（秒）
OFF_POLL=120              # 灭屏检查间隔（秒）
```

## 注意

- 亮度/充电为**内核 cooling device**，mi_thermald 会动态回写，靠守护检查后重写维持。
- 全部为内存态节点，重启自动恢复，不会变砖。
- 长期高温会加速电池老化，请自行权衡。