#!/system/bin/sh
# ============================================================
#  温控放宽 v2.1 · 自检脚本
#  用法： su -c "sh /data/adb/modules/thermal_relax/test.sh"
# ============================================================
MODDIR=${0%/*}
[ -f "$MODDIR/config.sh" ] && . "$MODDIR/config.sh"

TM=/sys/devices/virtual/thermal/thermal_message
[ -d "$TM" ] || TM=/sys/class/thermal/thermal_message

echo "================================================"
echo " 温控放宽 v2.1 自检"
echo "================================================"

echo
echo "--- 1) 守护进程 ---"
ps -A -o PID,ARGS 2>/dev/null | grep 'thermal_relax_guard' | grep -v grep \
  && echo "  ^ 守护在跑" || echo "  守护未运行（重启模块后应出现）"

echo
echo "--- 2) CPU 免温控上限 ---"
echo "  cpu_nolimit_temp = $(cat $TM/cpu_nolimit_temp 2>/dev/null)  (期望 $NOLIMIT_TEMP)"
for c in 4 7; do
  echo "  cpu$c scaling_max_freq = $(cat /sys/devices/system/cpu/cpu$c/cpufreq/scaling_max_freq 2>/dev/null)"
done

echo
echo "--- 3) WiFi / 商店限速 ---"
echo "  wifi_limit            = $(cat $TM/wifi_limit 2>/dev/null)  (期望 0)"
echo "  market_download_limit = $(cat $TM/market_download_limit 2>/dev/null)  (期望 0)"

echo
echo "--- 4) 亮度 ---"
echo "  thermal_max_brightness = $(cat $TM/thermal_max_brightness 2>/dev/null)  (期望 0)"
for b in /sys/class/backlight/*/brightness; do
  [ -e "$b" ] && echo "  $b = $(cat $b 2>/dev/null) / $(cat ${b%brightness}max_brightness 2>/dev/null)"
done

echo
echo "--- 5) 充电温度限流 ---"
for c in /sys/class/thermal/cooling_device*; do
  [ "$(cat $c/type 2>/dev/null)" = "battery" ] && \
    echo "  $c: cur=$(cat $c/cur_state 2>/dev/null) / max=$(cat $c/max_state 2>/dev/null)"
done
echo "  charge_control_limit = $(cat /sys/class/power_supply/battery/charge_control_limit 2>/dev/null)"

echo
echo "--- 6) 最近日志 ---"
tail -8 "$MODDIR/thermal_relax.log" 2>/dev/null || echo "  (无日志)"
echo
echo "================================================"