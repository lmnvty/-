#!/system/bin/sh
# ============================================================
#  温控放宽 v2.1 · 开机启动脚本 (KernelSU / Magisk 通用)
#  late_start service 阶段以 root 执行
#
#  v2.1 核心变化：90 秒周期改为「检查式重写」
#    到点先读当前值：
#      - 还是本模块设的值  -> 不写（省电省资源）
#      - 被改回原厂值      -> 立即重写回来
#
#  节奏：
#    亮屏 -> 检查1次 -> 等5秒再检查1次 -> 之后每 ON_INTERVAL(90s) 检查1次
#    灭屏 -> 每 OFF_POLL(120s) 只检查「充电/CPU」节点，不碰亮度
#
#  放宽项：
#    CPU 免温控上限 / WiFi 限速 / 温控降亮度 / 商店下载限速
#    充电不受温度限流（只解除温控压制，不改硬件电流上限）
#    背光满血
# ============================================================
MODDIR=${0%/*}
[ -f "$MODDIR/config.sh" ] && . "$MODDIR/config.sh"

TM=/sys/devices/virtual/thermal/thermal_message
[ -d "$TM" ] || TM=/sys/class/thermal/thermal_message

LOG=$MODDIR/thermal_relax.log
PIDF=$MODDIR/daemon.pid

# 参数默认值（防 config.sh 缺失）
[ -n "$NOLIMIT_TEMP" ]        || NOLIMIT_TEMP=50000
[ -n "$ON_INTERVAL" ]         || ON_INTERVAL=90
[ -n "$FIRST_REWRITE_DELAY" ] || FIRST_REWRITE_DELAY=5
[ -n "$OFF_POLL" ]            || OFF_POLL=120

log(){ echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

# 等节点就绪（最多 60 秒）
i=0
while [ ! -d "$TM" ] && [ $i -lt 60 ]; do sleep 1; i=$((i+1)); done

# ---------- 节点定位 ----------
# 充电限流：battery cooling device
CHARGE_CDEV=""
for c in /sys/class/thermal/cooling_device*; do
  [ "$(cat $c/type 2>/dev/null)" = "battery" ] && CHARGE_CDEV="$c" && break
done
# 备选：power_supply/battery/charge_control_limit
CHARGE_PS=/sys/class/power_supply/battery/charge_control_limit

# 背光节点
BACKLIGHT=""
for b in /sys/class/backlight/*/brightness; do
  [ -e "$b" ] && BACKLIGHT="$b" && break
done

# 屏幕状态探测节点：优先 backlight 实际亮度
SCREEN_BRIGHT=""
for b in /sys/class/backlight/*/actual_brightness; do
  [ -e "$b" ] && SCREEN_BRIGHT="$b" && break
done

export NOLIMIT_TEMP RELAX_WIFI RELAX_BRIGHT RELAX_MARKET RELAX_CHARGE \
       ON_INTERVAL FIRST_REWRITE_DELAY OFF_POLL TM SCREEN_BRIGHT \
       CHARGE_CDEV CHARGE_PS BACKLIGHT LOG

# 杀旧守护（按命令行特征）
for p in $(ps -A -o PID,ARGS 2>/dev/null | grep 'thermal_relax_guard' | grep -v grep | awk '{print $1}'); do
  kill -9 "$p" 2>/dev/null
done
[ -f "$PIDF" ] && kill -9 "$(cat $PIDF 2>/dev/null)" 2>/dev/null

# 拉起守护（初始写入由守护第一轮完成）
setsid /system/bin/sh -c '
  # thermal_relax_guard
  W="$SCREEN_BRIGHT"

  # check_write <文件> <目标值>
  #   值已正确 -> 返回 1（不写）
  #   值不对   -> 写入并返回 0
  cw(){
    [ -e "$1" ] || return 1
    cur=$(cat "$1" 2>/dev/null)
    [ "$cur" = "$2" ] && return 1
    echo "$2" > "$1" 2>/dev/null
    return 0
  }

  # $1=1 全量（含亮度） | $1=0 只充电/CPU（灭屏）
  apply(){
    n=0
    cw "$TM/cpu_nolimit_temp" "$NOLIMIT_TEMP" && n=$((n+1))

    [ "$RELAX_WIFI"   = 1 ] && { cw "$TM/wifi_limit" 0 && n=$((n+1)); }
    [ "$RELAX_MARKET" = 1 ] && { cw "$TM/market_download_limit" 0 && n=$((n+1)); }

    if [ "$RELAX_CHARGE" = 1 ] && [ -n "$CHARGE_CDEV" ]; then
      M=$(cat "$CHARGE_CDEV/max_state" 2>/dev/null)
      [ -n "$M" ] && { cw "$CHARGE_CDEV/cur_state" "$M" && n=$((n+1)); }
    fi

    if [ "$1" = 1 ] && [ "$RELAX_BRIGHT" = 1 ]; then
      cw "$TM/thermal_max_brightness" 0 && n=$((n+1))
      if [ -n "$BACKLIGHT" ]; then
        MB=$(cat "${BACKLIGHT%brightness}max_brightness" 2>/dev/null)
        [ -n "$MB" ] && { cw "$BACKLIGHT" "$MB" && n=$((n+1)); }
      fi
    fi

    # 仅在真的发生重写时记一行日志
    [ "$n" -gt 0 ] && echo "$(date "+%m-%d %H:%M:%S") rewrite $n 项 (full=$1)" >> "$LOG"
    return 0
  }

  prev=0
  while true; do
    # ---- 判断屏幕状态 ----
    if [ -n "$W" ]; then
      v=$(cat "$W" 2>/dev/null)
      if [ -n "$v" ] && [ "$v" -gt 0 ] 2>/dev/null; then on=1; else on=0; fi
    else
      if dumpsys power 2>/dev/null | grep -q "mWakefulness=Awake"; then on=1; else on=0; fi
    fi

    if [ "$on" = 1 ]; then
      if [ "$prev" = 0 ]; then
        # 刚亮屏：检查1次 -> 5秒后再检查1次 -> 之后每90秒
        apply 1
        sleep "$FIRST_REWRITE_DELAY"
        apply 1
        sleep "$ON_INTERVAL"
      else
        apply 1
        sleep "$ON_INTERVAL"
      fi
      prev=1
    else
      # 灭屏：只检查充电/CPU
      apply 0
      sleep "$OFF_POLL"
      prev=0
    fi
  done
' >/dev/null 2>&1 &

PID=$!
echo "$PID" > "$PIDF"
log "started v2.1 nolimit=$NOLIMIT_TEMP wifi=$RELAX_WIFI bright=$RELAX_BRIGHT market=$RELAX_MARKET charge=$RELAX_CHARGE on=$ON_INTERVAL first=$FIRST_REWRITE_DELAY off=$OFF_POLL pid=$PID"